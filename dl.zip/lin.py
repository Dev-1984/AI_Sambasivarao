from torch.utils.data import Dataset
import torch
class SimpleDataset(Dataset):
  def __init__(self):
    self.X = torch.linspace(0,10,50).unsqueeze(1)
    print(self.X)
    self.y = 3*self.X
    print(self.y)
    def __len__(self):
      return len(self.X)

    def __getitem__(self,idx):
     return self.X[idx], self.y[idx]

Dataset = SimpleDataset()
print(Dataset[10]) 