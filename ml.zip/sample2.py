import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

data = load_breast_cancer()  # data = { data:{"sample1"} }
X = pd.DataFrame(data.data, columns=data.feature_names)     
y = pd.Series(data.target)                                  

print("Feature columns (first 5):")
print(X.columns[:5])
print("Class names:", data.target_names)  # ['malignant' 'benign']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)  #stratify - same proportion in both X and y

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)  # learn scaling from train.      
X_test_scaled = scaler.transform(X_test)        # apply same transform to test. 

# train the model
model = LogisticRegression(max_iter=1000)  # max_iter increased to ensure convergence.  10000 samples. (1000 sample ) (time)
model.fit(X_train_scaled, y_train)

#  Make predictions
y_pred = model.predict(X_test_scaled)
y_proba = model.predict_proba(X_test_scaled)[:, 1]  # probability of class '1' (benign)

#  Evaluate
print("\nAccuracy on test set:", accuracy_score(y_test, y_pred))
print("\nClassification report:")
print(classification_report(y_test, y_pred, target_names=data.target_names))

print("Confusion matrix (rows=true, cols=predicted):")
print(confusion_matrix(y_test, y_pred))

# Inspect model coefficients (optional, for understanding)
coefficients = pd.Series(model.coef_[0], index=X.columns).sort_values(key=abs, ascending=False)
print("\nTop 10 features by absolute coefficient value:")
print(coefficients.head(10))
