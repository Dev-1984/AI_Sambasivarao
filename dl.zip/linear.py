import torch
import torch.nn as nn
torch.manual_seed(0)
X = torch.linspace(0,10,100).unsqueeze(1)
True_w = 2.0
True_b = 1.0
y = True_w * True_b + torch.rand_like(X)
model = nn.linear(1,1)
torch.optim.SGD(model.parameters(), lr=0.01)

for epoch in range(500):
y_pred = model(X)
loss = criterion(y_pred,y)
optimizer.zero_grad()
    loss.backward() # w.  b
    optimizer.step()


if (epoch +1) %100 ==0:
    print(epoch+1)
    print(f"{loss.item():.4f}")
print("learned parameters :")
for name,param in model.names_parameters():
    print(name,param.data) 



