import tensorflow as tf
from tensorflow.keras import layers, models
import matplotlib.pyplot as plt
import numpy as np
# 1. Load MNIST Dataset
# ================================
(X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()

# ================================
# 2. Normalize the Data (0–255 → 0–1)
# ================================
X_train = X_train / 255.0
X_test = X_test / 255.0

# ================================
# 3. Reshape Data for CNN
# (samples, height, width, channels)
# ================================
X_train = X_train.reshape(-1, 28, 28, 1)
X_test = X_test.reshape(-1, 28, 28, 1)

# ================================
# 4. Build CNN Model
# ================================
model = models.Sequential()

# Convolution + ReLU
model.add(layers.Conv2D(32, (3,3), activation='relu', input_shape=(28,28,1)))

# Max Pooling
model.add(layers.MaxPooling2D((2,2)))

# Flatten
model.add(layers.Flatten())

# Fully Connected Layer
model.add(layers.Dense(128, activation='relu'))

# Output Layer (0–9 digits)
model.add(layers.Dense(10, activation='softmax'))

# ================================
# 5. Compile the Model
# ================================
model.compile(
    optimizer='adam',
    loss='sparse_categorical_crossentropy',
    metrics=['accuracy']
)

# ================================
# 6. Train the Model
# ================================
print("Training started...")
model.fit(X_train, y_train, epochs=5, validation_split=0.1)

# ================================
# 7. Evaluate the Model
# ================================
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print("Test Accuracy:", test_accuracy)

# ================================
# 8. Test with One Image (Prediction)
# ================================
index = 10   # change index to test different images
sample_image = X_test[index]

prediction = model.predict(sample_image.reshape(1,28,28,1))
predicted_digit = np.argmax(prediction)

# ================================
# 9. Display Result
# ================================
plt.imshow(sample_image.reshape(28,28), cmap='blue')
plt.title(f"Predicted Digit: {predicted_digit}")
plt.axis('off')
plt.show()




