from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt
X,y = load_iris(return_X_y=True)

X_train1,X_test1,y_train1,y_test1=train_test_split(X,y,test_size=0.5,random_state=42,)
model =LogisticRegression(max_iter=200)
model.fit(X_train1,y_train1)
y_predictions = model.predict(X_test1)
cm = confusion_matrix(y_test1,y_predictions)
print(cm)