from sklearn.decomposition import PCA
from sklearn.datasets import load_iris
data = load_iris()
X = data.data
model = PCA(n_components=3)
X1 = model.fit_transform(X)
print(X1)




from sklearn.decomposition import PCA
import numpy as np
X = np.array([
     [2,4,7,8],
     [4,5,7,8],
     [3,5,6,7],

 ])
pca = PCA(n_components=1)
X_reduced = pca.fit_transform(X)
print(X)
print(X_reduced)







# from sklearn.ensemble import RandomForestRegressor
# X = [[500],[600],[800],[900]]
# y = [5,6,7,8]
# model = RandomForestRegressor(n_estimators=10)
# model.fit(X,y)
# print(model.predict([[900]]))


# from sklearn.ensemble import RandomForestClassifier
# X = [[30],[40],[50],[60],[70],[80]]
# y = [0, 0, 0, 1, 1, 1]
# model = RandomForestClassifier(n_estimators=10)
# model.fit(X,y)
# print(model.predict([[45]]))
# print(model.predict([[1000]]))