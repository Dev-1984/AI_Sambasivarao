import torch
# x = torch.tensor(2.0, requires_grad=True)
# y = x ** 2 + 3*x + 1
# y.backward()
# print(x.grad)
# m = torch.tensor([[1,2],[3,4]])
# v = torch.tensor([1.0,2.0,3.0])
# print( m * v[:3] )
# m = torch.tensor([[1,2],[3,4]])
# v = torch.tensor([1.0,2.0,3.0])
# print( m * v[:2] )
# v = torch.tensor([1.0,2.0,3.0])
# print(v+1)
# print(v*2)

# m1 = torch.tensor([[1],[2]])
# print(m1)
# print(m1.shape)

# v1 = torch.tensor([1.0,2.0,3.0])
# print(v1)
# print(v1.shape)





#print(torch.__version__)
# x1 = torch.tensor(3.0)
# print(x1)
# print(x1.shape)
