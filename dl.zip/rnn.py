import numpy as np
from tensorflow.keras.models import Sequential

from tensorflow.keras.layers import SimpleRNN, Dense


X = np.array([[[1],[2],[3]]])
y = np.array([[4]])
model = Sequential()
model.add(SimpleRNN(10, activation='tanh', input_shape=(3,1)))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mse')
model.fit(X, y, epochs=200, verbose=0)
prediction = model.predict(X)
print(prediction)



