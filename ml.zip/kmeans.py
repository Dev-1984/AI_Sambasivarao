# from sklearn.cluster import KMeans
# import pandas as pd
# X = np.array([[2,0],[2,4],[3,4],[3,6],[5,9],[5,10]])
# KMeans = KMeans(n_clusters=3)
# KMeans.fit(X)
# print(KMeans.labels_)
# print(KMeans.cluster_centers_)

from sklearn.cluster import KMeans
import numpy as np
X = np.array([[1,4],[1,0],[5,0],[5,1],[5,2],[10,2],[10,4],[10,0]])
kmeans = KMeans(n_clusters=3)
kmeans.fit(X)
print(kmeans.labels_)
print(kmeans.cluster_centers_)