import torch
import torch.nn as nn
from torch.utils.data import DataLoader,TensorDataset
torch.manual_seed(0)
X = torch.randn(200,2)
y = (X[:,0] + X[:,1]>0).long()
dataset = TensorDataset(X,y)
loader = DataLoader(dataset, batch_size=16,shuffle=True)
class FeedForwardNN(nn.Module):
    def __init__(self):
        super().__init__()

        self.fc1 = nn.Linear(2,16)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(16,2)

    def forward(self,x):
            x = self.fc1(x)
            x = self.relu(x)
            x = self.fc2(x)
            return x
model = FeedForwardNN()
loss_fn = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(),lr=0.01)

num_epoch = 20
for epoch in range(num_epoch):
    total_loss = 0
    correct = 0
    total = 0

    for X_batch, y_batch in loader:
         outputs = model(X_batch)
         loss = loss_fn(outputs, y_batch)

         optimizer.step()

         total_loss += loss.item() * X_batch.size(0)
         predcitions = outputs.argmax(dim=1)
         correct += (predcitions == y_batch).sum().item()
         total += y_batch.size(0)
         avg_loss = total_loss / total
         accuracy = correct / total
         print(f"Epoch {epoch+1:02d} | loss:{avg_loss:.4f} | Accuracy: {accuracy:.2f}")




