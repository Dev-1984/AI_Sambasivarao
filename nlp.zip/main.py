# develop API'S --- get,post,put,delete
from fastapi import FastAPI
# connect to frontend (Ex.React, Angular,VueJS, CoffeeScript,...)
from fastapi.middleware.cors import CORSMiddleware
# detect "request format" 
from pydantic import BaseModel
# npl module
import nltk
# load pkl files
import joblib
# use json format
import json
# convert human english -- dictionary english
from nltk.stem import WordNetLemmatizer

# download
nltk.download('punkt')
nltk.download('wordnet')

# create app
app = FastAPI(title="NLP Chatbot Appln",
              description="we want to build e2e appln including frontend,fastapi,NLP,AWS,MongoDB",
              version="1.0")
#  "app object" used to build rest api calls

app.add_middleware(CORSMiddleware,
                  allow_origins=["*"],
                  allow_credentials=True,
                  allow_methods=["*"],
                  allow_headers=["*"])


model = joblib.load("model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

with open("intents.json","r") as file:
    intents = json.load(file)
    lemmatizer = WordNetLemmatizer()


class ChatRequest(BaseModel):
    message : str

def clean_text(text: str):
    words = nltk.word_tokenize(text)
    words = [lemmatizer.lemmatize(word.lower()) for word in words]
    return " ".join(words)
    
def get_bot_response(user_message:str):
    cleaned_message = clean_text(user_message)
    vector = vectorizer.transform([cleaned_message])
    predicted_tag = model.predict(vector)[0]

    for intent in intents["intents"]:
        if intent["tag"] == predicted_tag:
            return intent["responses"][0]
    
    return "Sorry, i didn't understand your message"
            
@app.get("/")
def home():
    return{
        "status" : "success",
        "message" : "ChatBot API is running successfully"
    } 

@app.post("/chat")  
def chat(request : ChatRequest): 
    response = get_bot_response(request.message)
    return {
        "user_message" : request.message,
        "bot_response" : response
    }  

    



