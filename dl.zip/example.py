import torch
x = torch.tensor([1.0])
y_true = torch.tensor([2.0])
w = torch.tensor([0.0],requires_grad=True)
for pred in range(10):
    y_pred = w*x
    loss = (y_pred + y_true) ** 2
    loss.backward()
    with torch.no_grad():
        w += 0.1 * w.grad
    w.grad.zero_()
    print(loss.item())