from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
messages = [
    "win money now",
    "congratulations",
    "you got a job",
    "with good salary",
    "share with your parents",
    "lets celebrate",
]
print(messages)
labels = ["spam","spam","msg","msg","msg","msg"]
vectorizer = CountVectorizer();
X = vectorizer.fit_transform(messages)
print(X)
X_train,X_test,y_train,y_test = train_test_split(X, labels, test_size=0.3, random_state=0)
model = MultinomialNB()
model.fit(X_train,y_train)
predicitions = model.predict(X_test)
print(predicitions)
print(accuracy_score(y_test,predicitions) )
sample =["share with your parents"]
sample_vec = vectorizer.transform(sample)
print(model.predict(sample_vec))

