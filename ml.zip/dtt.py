from sklearn.tree import DecisionTreeClassifier
import numpy as np
X = np.array([[1,1],[1,0],[0,1],[0,0]])
y = np.array([1,1,0,0])
model = DecisionTreeClassifier()
model.fit(X,y)
predictions = model.predict([[1,0]])
print(predictions)