from sklearn.model_selection import train_test_split
import numpy as np
X = np.array([1,2,3,4,5,6,7,8,9])
y = np.array([1,1,1,0,0,0,1,1,1])
X_train1,X_test1,y_train1,y_test1=train_test_split(X,y,test_size=0.3)
X_train2,X_test2,y_train2,y_test2=train_test_split(X,y,test_size=0.3)
print(X_train1)
print(X_train2)