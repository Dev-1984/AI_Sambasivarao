#import
import pandas as pd
import matplotlib.pyplot as ply
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

#Data
data = {
    "size_sqft" : [600,800,1000,1200,1400,1600],   
    "price" : [150000,180000,210000,250000,280000,310000]
}
df = pd.DataFrame(data)

# Features (labels)
X = df[["size_sqft"]]
y = df["price"]

# 20% data --- test. 80% data. ---- Train
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=42);


model = LinearRegression()
model.fit(X_train,y_train)

predictions = model.predict(X_test)

print("Test sizes", list(X_test["size_sqft"]))  
print("Prediction Prices:",list(predictions))
print("Actual Prices:",list(y_test))
print("Model slope (coef)",model.coef_[0])
print("Model intercept :",model.intercept_)

ply.scatter(df["size_sqft"],df["price"],label="data")
xs = pd.DataFrame({"size_sqft":sorted(df["size_sqft"])})
ply.plot(xs["size_sqft"],model.predict(xs),label="Regression Line")
ply.xlabel("Size(sqrt)")
ply.ylabel("Price")
ply.title("Very Basic Example")
ply.legend()
ply.show()