from sklearn.tree import DecisionTreeClassifier
import numpy as np
X = np.array([[1,1],[1,0],[0,1],[0,0]])
y = np.array([1,1,0,0])
model = DecisionTreeClassifier()
model.fit(X,y)
predictions = model.predict([[1,0]])
print(predictions)



# from sklearn.neighbors import KNeighborsClassifier
# import numpy as np
# X = np.array([[50,160],[55,165],[80,180],[85,190]])
# y = np.array([0,0,1,1])
# model = KNeighborsClassifier(n_neighbors=3)
# model.fit(X,y)
# predictions = model.predict([[70,175]])
# print(predictions)